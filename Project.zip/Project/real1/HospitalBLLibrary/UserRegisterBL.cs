﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using HospitalModeLibrary;
using HospitalDALLibrary;
namespace HospitalBLLibrary
{
    public class UserRegisterBL
    {
        UserRegisterDAL urdal;
        List<UserRegister> userregister;
        public UserRegisterBL()
        {
            urdal = new UserRegisterDAL();
        }
        public List<UserRegister> GetAll_URdetails()
        {
            userregister = urdal.Get_URdetailsfromdatabase();
            return userregister;
        }
        public bool Update_UR(UserRegister userRegister)
        {
            bool bResult = false;
            GetAll_URdetails();
            Predicate<UserRegister> check_Username = m => m.UserName == userRegister.UserName;
            if (userregister.Find(check_Username) == null)
            {
                if (urdal.Update_URinto_DB(userRegister))
                    bResult = true;
            }
            else
                throw new DuplicationUserRegException(userRegister.UserName);
            return bResult;
        }
        public DataTable UserBLL(modellinlog da)
        {
            urdal = new UserRegisterDAL();
            return urdal.loginuser(da);
        }
        public int  userbooking (string name,string d,string doc,string spe)
        {
           return  urdal.userbooking(name, d, doc, spe);
        }
        public void remove(string s)
        {

            urdal.remove(s);
        }
    }
}













        //public List<Speciality> GetSpecialityListBL()
        //{
        //    urdal = new UserRegisterDAL();
        //    return urdal.GetSpecialityList();
        //}
        //public List<Doctor> GetDoctorList(int S_id)
        //{
        //    urdal = new UserRegisterDAL();
        //    return urdal.GetDoctorList(S_id);
        //}
        //public Doctorappointment Doctor_appointment(string Username)
        //{
        //    urdal = new UserRegisterDAL();
        //    return urdal.GetDoctorAppointment(Username);
        //}
        //public List<Doctorappointment> GetDoctor_appointment()
        //{
        //    urdal = new UserRegisterDAL();
        //    return urdal.GetDoctor_appointmentDetails();
        //}
    


    