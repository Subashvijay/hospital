﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalModeLibrary;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using HospitalDALLibrary;

namespace HospitalDALLibrary
{
    public class UserRegisterDAL
    {
        SqlConnection con;
        SqlDataAdapter daUserRegister;
        SqlCommand cmd_UR;
        
        public UserRegisterDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["conHospital"].ConnectionString);
            daUserRegister = new SqlDataAdapter("proc_Get_User_Reg", con);
            daUserRegister.SelectCommand.CommandType = CommandType.StoredProcedure;
            cmd_UR = new SqlCommand("proc_User_Reg",con);
            //cmd_UR.Connection = con;
            cmd_UR.CommandType = CommandType.StoredProcedure;
            cmd_UR.Parameters.Add("@First_Name",SqlDbType.VarChar,50);
            cmd_UR.Parameters.Add("@Last_Name", SqlDbType.VarChar, 50);
            cmd_UR.Parameters.Add("@Age",SqlDbType.Int);
            cmd_UR.Parameters.Add("@Gender", SqlDbType.VarChar, 50);
            cmd_UR.Parameters.Add("@Contact_number", SqlDbType.VarChar,10);
            cmd_UR.Parameters.Add("@Email", SqlDbType.VarChar, 50);
            cmd_UR.Parameters.Add("@UserName", SqlDbType.VarChar, 50);
            cmd_UR.Parameters.Add("@Password", SqlDbType.VarChar, 50);
        }
        public List<UserRegister> Get_URdetailsfromdatabase()
        {
            List<UserRegister> DB_UR = new List<UserRegister>();
            DataSet ds_UR = new DataSet();
            daUserRegister.Fill(ds_UR);
            UserRegister UR =new UserRegister();;
            foreach (DataRow dr in ds_UR.Tables[0].Rows)
            {
                
                UR.FirstName=dr[0].ToString();
                UR.Lastname = dr[1].ToString();
                UR.Age = int.Parse(dr[2].ToString());
                UR.Gender = dr[3].ToString();
                UR.ContactNumber = long.Parse(dr[4].ToString());
                UR.Email = dr[5].ToString();
                UR.UserName = dr[6].ToString();
                UR.Password = dr[7].ToString();
                DB_UR.Add(UR);
            }
            return DB_UR;
        }
        public bool Update_URinto_DB(UserRegister userRegister)
        {
            bool bResult = false;
            cmd_UR.Parameters[0].Value = userRegister.FirstName;
            cmd_UR.Parameters[1].Value = userRegister.Lastname;
            cmd_UR.Parameters[2].Value = userRegister.Age;
            cmd_UR.Parameters[3].Value = userRegister.Gender;
            cmd_UR.Parameters[4].Value = userRegister.ContactNumber;
            cmd_UR.Parameters[5].Value = userRegister.Email;
            cmd_UR.Parameters[6].Value = userRegister.UserName;
            cmd_UR.Parameters[7].Value = userRegister.Password;
            if (con.State == ConnectionState.Open)
                con.Close();
            con.Open();
            int _iResult = cmd_UR.ExecuteNonQuery();
            if (_iResult == 1)
                bResult = true;
            con.Close();
            return bResult;
        }
        public DataTable loginuser(modellinlog da)
        {
            DataTable dt = new DataTable();
            con.Open();
            cmd_UR = new SqlCommand("select * from UserInfo where UserName='" + da.Username + "'and Password='" + da.Password + "'", con);
            SqlDataAdapter daUserRegister = new SqlDataAdapter(cmd_UR);
            daUserRegister.Fill(dt);
            return dt;
        }

       public DataSet retdocInfo()
        {
            DataSet d = new DataSet();
            daUserRegister = new SqlDataAdapter("ret_Doc_detail", con);
            daUserRegister.Fill(d);
            return d;

        }
       public DataSet retspecInfo(string s)
       {
           DataSet d = new DataSet();
           cmd_UR = new SqlCommand("ret_spec_detail", con);
           cmd_UR.CommandType = CommandType.StoredProcedure;
           cmd_UR.Parameters.Add("@name",SqlDbType.VarChar,50);
           cmd_UR.Parameters[0].Value = s;
           daUserRegister = new SqlDataAdapter(cmd_UR);

           daUserRegister.Fill(d);
           return d;

       }

       public int userbooking(string name, string d, string doc, string spe)
       {
           cmd_UR = new SqlCommand("insert_book_table", con);
           cmd_UR.CommandType = CommandType.StoredProcedure;
           cmd_UR.Parameters.Add("@username", SqlDbType.VarChar, 50);
           cmd_UR.Parameters.Add("@date", SqlDbType.VarChar, 50);
           cmd_UR.Parameters.Add("@docname", SqlDbType.VarChar, 50);
           cmd_UR.Parameters.Add("@spec", SqlDbType.VarChar, 50);
           cmd_UR.Parameters[0].Value = name;
           cmd_UR.Parameters[1].Value = d;
           cmd_UR.Parameters[2].Value = doc;
           cmd_UR.Parameters[3].Value = spe;
           if (con.State == ConnectionState.Open)
               con.Close();
           con.Open();
          return cmd_UR.ExecuteNonQuery();
           
       }

       public void remove(string s)
       {
           cmd_UR = new SqlCommand("Remove_booking", con);
           cmd_UR.CommandType = CommandType.StoredProcedure;
           cmd_UR.Parameters.Add("@name",SqlDbType.VarChar,50);
           cmd_UR.Parameters[0].Value = s;
           con.Open();
            cmd_UR.ExecuteNonQuery();


       }
        
  
        //public List<Speciality> GetSpecialityList()
        //{
        //    List<Speciality> list_speciality = new List<Speciality>();
        //    con.Open();
        //    cmd_UR = new SqlCommand("speciality_details", con);
        //    cmd_UR.CommandType = CommandType.StoredProcedure;
        //    daUserRegister = new SqlDataAdapter(cmd_UR);
        //    DataSet dt = new DataSet();
        //    daUserRegister.Fill(dt);
        //    foreach (DataRow dr in dt.Tables[0].Rows)
        //    {
        //        Speciality spel = new Speciality();
        //        spel.S_id = Convert.ToInt32(dr[0].ToString());
        //        spel.Speciality1 = dr[1].ToString();
        //        list_speciality.Add(spel);
        //    }
        //    con.Close();
        //    return list_speciality;
        //}
        //public List<Doctor> GetDoctorList(int S_id)
        //{
        //    List<Doctor> list_doctor = new List<Doctor>();
        //    con.Open();
        //    cmd_UR = new SqlCommand("doctor_details", con);
        //    cmd_UR.CommandType = CommandType.StoredProcedure;
        //    cmd_UR.Parameters.AddWithValue("@s_id", S_id);
        //    daUserRegister = new SqlDataAdapter(cmd_UR);
        //    DataSet dt = new DataSet();
        //    daUserRegister.Fill(dt);
        //    foreach (DataRow dr in dt.Tables[0].Rows)
        //    {
        //        Doctor doc = new Doctor();
        //        doc.D_id = Convert.ToInt32(dr[0].ToString());
        //        doc.S_id = Convert.ToInt32(dr[0].ToString());
        //        doc.Doctorname = dr[1].ToString();
        //        list_doctor.Add(doc);
        //    }
        //    con.Close();
        //    return list_doctor;
        //} 
        //public Doctorappointment Doctor_appointment()
        //{
        //    Doctorappointment D_A = new Doctorappointment();
        //    con.Open();
        //    cmd_UR = new SqlCommand("DoctorAppointment_details", con);
        //    cmd_UR.CommandType = CommandType.StoredProcedure;
        //    cmd_UR.Parameters.AddWithValue("@userID", userID);
        //    daUserRegister= new SqlDataAdapter(cmd);
        //    DataSet dt = new DataSet();
        //    sda.Fill(dt);
        //    foreach (DataRow dr in dt.Tables[0].Rows)
        //    {
        //        user.FirstName = dr[0].ToString();
        //        user.LastName = dr[1].ToString();
        //        user.Gender = dr[2].ToString();
        //        user.PhoneNumber = Convert.ToInt32(dr[3].ToString());
        //        user.City = dr[4].ToString();
        //        user.Facility = dr[5].ToString();
        //        user.BuildingNumber = dr[6].ToString();
        //    }
        //    conn.Close();
        //    return user;
        //}
        //public List<Doctorappointment>
    }}
