﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalModeLibrary
{
    public class Doctorappointment
    {
    //    string _speciality;
    //    public string Speciality
    //    {
    //        get { return _speciality; }
    //        set { _speciality = value; }
    //    }
    //    string _doctor;
    //    string _date;

    //    public string Date
    //    {
    //        get { return _date; }
    //        set { _date = value; }
    //    }
    //    public string Doctor
    //    {
    //        get { return _doctor; }
    //        set { _doctor = value; }
    //    }
    //    public Doctorappointment()
    //    { }
    //    public Doctorappointment(string Speciality, string Doctor,string Date)
    //    {
    //        this._speciality = Speciality;
    //        this._doctor = Doctor;
    //        this._date = Date;
    //    }
    }
}
