﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace HospitalModeLibrary
{
    public class UserRegister:IComparable<UserRegister>
    {
        string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        string _lastname;

        public string Lastname
        {
            get { return _lastname; }
            set { _lastname = value; }
        } 
        int _age;

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
        string _gender;

        public string Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }
        long _contactNumber;

        public long ContactNumber
        {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }
        string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        string _userName;

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }
        string _password;

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        string _reTypePassword;

        public string ReTypePassword
        {
            get { return _reTypePassword; }
            set { _reTypePassword = value; }
        }
        public int CompareTo(UserRegister other)
        {
            return this.UserName.CompareTo(other.UserName);
        }
    }
}
