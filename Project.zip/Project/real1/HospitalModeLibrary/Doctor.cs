﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalModeLibrary
{
   public class Doctor
    {
   //     int d_id;

   //     public int D_id
   //     {
   //         get { return d_id; }
   //         set { d_id = value; }
   //     }
   //     int s_id;

   //     public int S_id
   //     {
   //         get { return s_id; }
   //         set { s_id = value; }
   //     }
   //     string _doctorname;

   //     public string Doctorname
   //     {
   //         get { return _doctorname; }
   //         set { _doctorname = value; }
   //     }
   //     public Doctor()
   //     { }
   //     public Doctor(int d_id, int s_id, string _doctorname)
   //     {
   //         this.d_id = d_id;
   //         this.s_id = s_id;
   //         this._doctorname = _doctorname;
   //     }
    }
}
