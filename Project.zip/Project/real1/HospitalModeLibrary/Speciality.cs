﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalModeLibrary
{
    public class Speciality
    {
    //    int s_id;

    //    public int S_id
    //    {
    //        get { return s_id; }
    //        set { s_id = value; }
    //    }
    //    string _speciality;

    //    public string Speciality1
    //    {
    //        get { return _speciality; }
    //        set { _speciality = value; }
    //    }
    //    public Speciality()
    //    { }
    //    public Speciality(int s_id, string _speciality)
    //    {
    //        this.s_id = s_id;
    //        this._speciality = _speciality;
    //    }
    }
}
