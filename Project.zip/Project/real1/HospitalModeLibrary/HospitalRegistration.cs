﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace HospitalModeLibrary
{
    public class HospitalRegistration : IComparable<HospitalRegistration>
    {
        string _hospitalName;

        public string HospitalName
        {
            get { return _hospitalName; }
            set { _hospitalName = value; }
        }
        long _contactNumber;

        public long ContactNumber
        {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }
        string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        string _password;

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        public int CompareTo(HospitalRegistration other)
        {
            return this.HospitalName.CompareTo(other.HospitalName);
        }
    }
}
