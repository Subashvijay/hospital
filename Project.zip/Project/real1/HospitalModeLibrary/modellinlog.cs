﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalModeLibrary
{
    public class modellinlog
    {
        string _username;

        public string Username
        {
            get { return _username; }
            set { _username = value; }
        }
        string _password;

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        //public UserLogin()
        //{ }
        //public UserLogin(string _username, string _password)
        //{
        //    this._username = _username;
        //    this._password = _password;
        //}
    }
}
