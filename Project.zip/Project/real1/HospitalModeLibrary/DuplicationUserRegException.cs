﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalModeLibrary
{
    public class DuplicationUserRegException:ApplicationException
    {
        string myErrorMessegeUR;
        public DuplicationUserRegException(string name)
        {
            myErrorMessegeUR = name + " UserName Already Exists";
        }
        public override string Message
        {
            get 
            {
                return myErrorMessegeUR;
            }
        }
    }
}
