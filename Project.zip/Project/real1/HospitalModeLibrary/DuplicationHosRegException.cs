﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalModeLibrary
{
   public class DuplicationHosRegException:ApplicationException
    {
       string myErrorMessege;
       public DuplicationHosRegException()
       {
           myErrorMessege = "Hospital Name Already Exists";
       }
       public DuplicationHosRegException(string name)
       {
           myErrorMessege = name + "Hospital Name Already Exists";
       }
       public override string Message
       {
           get
           {
               return myErrorMessege;
           }
       }
    }
}
