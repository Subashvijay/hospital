﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using HospitalModeLibrary;
using HospitalBLLibrary;
namespace realFEProject
{
    public partial class UserLogin : System.Web.UI.Page
    {
        UserRegisterBL bl;
        modellinlog da = new modellinlog();
        DataTable dt = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //protected void btnlogin_Click(object sender, EventArgs e)
        ////{
        ////    da.Username = txtUserName.Text;
        ////    da.Password = txtPassword.Text;

        ////    dt = ur_BL.loginuser(da);
        ////    if (dt.Rows.Count > 0)
        ////    {
        ////        Response.Redirect("home.aspx");
        ////    }
        ////    else
        ////    {
        ////        Response.Write("<script>alert('invalid username or password')</script>");
        ////    }


        //}

        //protected void btnLogin_Click(object sender, EventArgs e)
        //{
        // da.Username = txtUserName.Text;
        //    da.Password = txtPassword.Text;
        //    bl = new UserRegisterBL();
        //    dt = bl.UserBLL(da);
        //    if (dt.Rows.Count > 0)
        //    {
        //        Response.Redirect("home.aspx");
        //    }
        //    else
        //    {
        //        Response.Write("<script>alert('invalid username or password')</script>");
        //    }
        //}

        protected void btnLogin_Click1(object sender, EventArgs e)
        {
            da.Username = txtUserName.Text;
            da.Password = txtPassword.Text;
            bl = new UserRegisterBL();
            dt = bl.UserBLL(da);
            if ((dt.Rows.Count > 0)&&(da.Username!="Doctor"))
            {
                Session["name"] = txtUserName.Text;
                Response.Redirect("User_Doctor.aspx");
               
            }
            else if ((da.Password == "123") && (da.Username == "Doctor"))
            {
                Response.Redirect("BookingDetails.aspx");
            }
            else
            {
                Response.Write("<script>alert('invalid username or password')</script>");
            }
            
        }

        //protected void txtUserName_TextChanged(object sender, EventArgs e)
        //{

        //}

        //protected void btnLogin_Click(object sender, EventArgs e)
        //{

        //}
    }
}