﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalBLLibrary;
using HospitalModeLibrary;

namespace realFEProject
{
    public partial class UserRegistration : System.Web.UI.Page
    {
        UserRegisterBL urbl = new UserRegisterBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btncreate_Click1(object sender, EventArgs e)
        {
            string message = "";
            UserRegister ur = new UserRegister();
            ur.FirstName = txtfirstname_UR.Text;
            ur.Lastname = txtlastname_UR.Text;
            ur.Age = int.Parse(txtage_UR.Text);
            ur.Gender = ddlgender_UR.Text;
            ur.ContactNumber = long.Parse(txtcontactnumber_UR.Text);
            ur.Email = txtemail_UR.Text;
            ur.UserName = txtusername_UR.Text;
            ur.Password = txtpassword_UR.Text;
            ur.ReTypePassword = txtretypepassword_UR.Text;
            try
            {
                if (urbl.Update_UR(ur) == true)
                {
                    message = "Registration Successful";
                }
            }
            catch (DuplicationUserRegException d_URe)
            {
                message = d_URe.Message;
            }
            catch (System.Data.SqlClient.SqlException)
            {
                message = "Server Unavailable Right Now";
            }
            catch (Exception)
            {
                message = "Some Error";
            }
            lbl_URmessage.Text = message;
        }
        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtfirstname_UR.Text = string.Empty;
            txtlastname_UR.Text = string.Empty;
            txtage_UR.Text = string.Empty;
            ddlgender_UR.Text = string.Empty;
            txtcontactnumber_UR.Text = string.Empty;
            txtemail_UR.Text = string.Empty;
            txtusername_UR.Text = string.Empty;
            txtpassword_UR.Text = string.Empty;
            txtretypepassword_UR.Text = string.Empty;
        }

        protected void btnback_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserLogin.aspx");
        }
    }
}