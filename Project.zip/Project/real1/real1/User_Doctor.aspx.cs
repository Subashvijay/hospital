﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalModeLibrary;
using HospitalBLLibrary;
namespace realFEProject
{
    public partial class User_Doctor : System.Web.UI.Page
    {
        //Doctorappointment da;
        //UserRegisterBL UR_BL;
        //protected void Page_Load(object sender, EventArgs e)
        //{
        //    if (!Page.IsPostBack)
        //    {
        //        UR_BL = new UserRegisterBL();
        //        List<Speciality> city = UR_BL.GetSpecialityListBL();
        //        DDLCity.DataSource = city;
        //        DDLCity.DataBind();
        //    }
        //}

        UserRegisterBL usbl = new UserRegisterBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            //SpecialityName.DataTextField = "Specialization";
            //SpecialityName.DataValueField = "Specialization";
            //SpecialityName.DataSource=usbl.DoctorInfo();
            //SpecialityName.DataBind();
            //Doctorname.DataTextField = "Name";
            //Doctorname.DataValueField = "Name";
            //string s = SpecialityName.SelectedItem.Text;
            //Doctorname.DataSource = usbl.specInfo(s);
            //Doctorname.DataBind();
            //string s = Session["name"].ToString();
            //Label1.Text = "Welcome  " + s;
        }


        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void btnLogout_Click1(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void btnbook_Click(object sender, EventArgs e)
        {
            string name = Session["name"].ToString();
            DateTime d = Calendar1.SelectedDate;
            string date = d.ToString("dd/MM/yyyy");
            string docname = Doctorname.SelectedItem.Text;
            string spec = SpecialityName.SelectedItem.Text;

            int n = usbl.userbooking(name, date, docname, spec);

            if (n == 1)
            {
                Label1.Text = "Booked sucessfully";
            }
            else
                Label1.Text = "Something wrong please try again";
        }

        protected void btnLogout_Click2(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }
    }
}